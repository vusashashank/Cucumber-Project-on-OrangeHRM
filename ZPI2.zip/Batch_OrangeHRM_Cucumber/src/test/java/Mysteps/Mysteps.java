package Mysteps;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class Mysteps {
	public static WebDriver driver;
	@Given ("Enter the URL to login")
	public void Enter_URL() {
		System.setProperty("Webdriver.driver.chromeDriver", "C:\\Users\\shash\\OneDrive\\Desktop\\Automation classes\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://127.0.0.1/orangehrm-2.5.0.2/login.php");
	}
	@Then("enter Username")
	public void enter_username() {
		driver.findElement(By.xpath("//input[@name='txtUserName']")).sendKeys("selenium");
	
	}
	@Then("Enter Password")
	public void enter_password() {
		driver.findElement(By.xpath("//input[@name='txtPassword']")).sendKeys("cypress");
	  
	}
	@Then("Click on Submit button")
	public void click_on_submit_button() {
		driver.findElement(By.xpath("//input[@name='Submit']")).click();
	    
	}

	
}
