package StepData;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {
	public static WebDriver driver;
	@Given("Enter the OranegHRM url")
	public void enter_the_oraneg_hrm_url() {
		System.setProperty("Webdriver.driver.chromeDriver", "C:\\Users\\shash\\OneDrive\\Desktop\\Automation classes\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://127.0.0.1/orangehrm-2.5.0.2/login.php");
	}
	@When("Enter the HomePage User name")
	public void enter_the_home_page_user_name() {
		driver.findElement(By.xpath("//input[@name='txtUserName']")).sendKeys("selenium");
	}
	@Then("Enter the HomePage Password")
	public void enter_the_home_page_password() {
		driver.findElement(By.xpath("//input[@name='txtPassword']")).sendKeys("cypress");
	}
	@Then("Hit on submit Button")
	public void hit_on_submit_button() {
		driver.findElement(By.xpath("//input[@name='Submit']")).click();
	}
	@Then("Check the  Title")
	public void check_the_title() {
		
		
	   
	}






}
