package TestPack1;

import org.junit.runner.RunWith;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\shash\\eclipse-workspace\\Batch_OrangeHRM_Cucumber\\src\\main\\java\\BasePack2\\Login.feature",glue="StepData")


public class TestClass{

}
